# MiniMax Director Distribution — 0.1.0-rc1

MiniMax H3 Director에서 장면별 생성·승인, Motion Context 연결, HyperFlow 스케줄, `.ext` 프로젝트 저장을 사용하는 **비공식 배포 후보**입니다.

현재는 독립 커스텀 노드가 아니라 **버전 고정 패치 묶음**입니다. 설치하면 DaSiWa와 Extender의 지정 파일 9개를 추가·교체합니다. 원본 업데이트에 자동으로 안전해지는 구조는 아닙니다. 업데이트 전 백업하고, 업데이트 후 `check`를 실행해야 합니다. 버전이 다르면 설치 도구는 덮어쓰기를 거부합니다.

## 준비

- MiniMax H3를 지원하는 ComfyUI. 개발 환경의 Core 커밋: `88ab4a06566454ad89db8f0bedb970d6c08cd1b7`. 다른 버전의 GPU 실행은 검증되지 않았습니다.
- DaSiWa 0.4.49, Extender, HyperFlow: **정확한 커밋은 `manifest.json`의 `dependencies` 참고**. 각 원본 저장소를 해당 커밋으로 설치하고 각 저장소의 의존성 설치 방법을 따르세요. 최신 버전과 혼용하지 마세요.
- MiniMax H3 Ref2VA 모델, 텍스트 인코더, video/audio VAE, 모델에 맞는 HyperFlow 가중치를 별도로 준비하세요. 이 묶음은 모델을 다운로드하지 않습니다.

원본 저장소 링크와 라이선스는 [NOTICE.md](NOTICE.md)에 있습니다.

## 설치

ComfyUI를 종료하고 이 폴더에서 실행합니다. `python`은 ComfyUI에 사용하는 Python입니다. Portable 환경에서는 `..\..\python_embeded\python.exe` 등의 실제 경로를 사용하세요.

```powershell
python manage.py --comfy "D:\ComfyUI_windows_portable\ComfyUI" check
python manage.py --comfy "D:\ComfyUI_windows_portable\ComfyUI" install
```

설치 전 전체 대상과 의존성 코드 해시를 검사합니다. Windows/Linux 줄바꿈 차이는 허용합니다. 알려진 원본 또는 이미 적용된 파일만 허용하며, 알 수 없는 수정본은 덮어쓰지 않습니다. 설치 백업은 `ComfyUI/user/director-...`에 생성되고 복구 명령이 출력됩니다. 해당 폴더는 개인 백업이며 공유하지 마세요.

ComfyUI를 다시 시작하고 브라우저를 새로고침한 뒤 `workflows/Director_Long_Video_HyperFlow.json`을 엽니다. 모델 로더 4개와 HyperFlow 파일을 자신의 파일명으로 선택하세요.

한국어 Windows에서 DaSiWa 시작 로그에 `UnicodeEncodeError: cp949`가 나오면 ComfyUI 실행 명령의 Python 뒤에 `-X utf8`을 넣으세요. 예: `python -X utf8 main.py`. 검증 서버도 이 옵션으로 정상 로딩했습니다.

## 예제 사용

1. 필요하면 Director의 레퍼런스 이미지 영역에 이미지를 추가합니다. 예제에는 개인 이미지가 없습니다.
2. 긴 영상 ON 상태에서 장면 프롬프트·길이·시드를 설정하고 생성합니다. 예제는 긴 영상 전용이며 OFF 경로는 구성하지 않았습니다.
3. 미리보기 확인 후 승인하고 다음 장면으로 이동합니다. **승인 자체는 생성을 실행하지 않습니다.** 다음 장면 생성 버튼을 눌러야 합니다.
4. 출력 노드의 `filename_prefix` 아래에 합친 영상이 저장됩니다. 기본값은 `ComfyUI/output/video/director/날짜/시간...`입니다.
5. 프로젝트 저장은 `.ext`에 Director 설정·참조 미디어·존재하는 장면 캐시를 함께 저장합니다. 모델 파일과 Settings 전체는 포함되지 않습니다. 워크플로우 JSON도 별도로 보관하세요.

공유 예제는 9개 노드로 새로 구성했습니다. 기존 개인 워크플로우, Ollama·Prompt Freeze 자동화, LoRA 목록과 미디어는 포함하지 않았습니다. 기존 워크플로우 파일을 자동 변경하지 않습니다. 장면의 외부 프롬프트 토글은 연결된 외부 프롬프트가 있을 때 사용하세요.

## 복구와 제한

```powershell
python manage.py --comfy "D:\ComfyUI_windows_portable\ComfyUI" rollback --backup "D:\ComfyUI_windows_portable\ComfyUI\user\director-백업폴더"
```

설치 후 다른 코드로 바뀐 파일은 복구 도구도 덮어쓰지 않습니다. 원본 업데이트 후에는 해당 버전에 맞춘 새 패치가 필요합니다.

이 패키지에서 독립 노드로의 완전 분리, 깨끗한 ComfyUI에서 실제 GPU 영상 생성, GitHub 공개는 아직 완료되지 않았습니다. 검증 범위는 [VALIDATION.md](VALIDATION.md)를 확인하세요. 원본 업데이트와 무관하게 유지되는 완성 배포판으로 취급하지 마세요.
