"""Offline, hash-checked installation and rollback. Stop ComfyUI before applying."""
import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes().replace(b'\r\n', b'\n')).hexdigest() if path.is_file() else None


def contained(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f'Path outside installation: {name}')
    return path


def inspect(comfy, manifest):
    base = comfy / 'custom_nodes'
    problems, changes = [], []
    for repo, dependency in manifest['dependencies'].items():
        for name, expected in dependency['runtime_sha256'].items():
            if sha(contained(base, repo + '/' + name)) != expected:
                problems.append(f'Dependency differs: {repo}/{name}')
    for entry in manifest['files']:
        source = contained(ROOT / 'payload', entry['path'])
        if sha(source) != entry['sha256']:
            problems.append(f'Package damaged: {entry["path"]}')
            continue
        dest = contained(base, entry['path'])
        actual = sha(dest)
        if actual == entry['sha256']:
            continue
        if actual != entry['base_sha256'] or (actual is None and dest.exists()):
            problems.append(f'Unrecognized version: {entry["path"]}')
        else:
            changes.append(entry)
    return problems, changes


def install(comfy, manifest, changes):
    backup = Path(tempfile.mkdtemp(prefix='director-', dir=comfy / 'user'))
    records = []
    for entry in changes:
        dest = contained(comfy / 'custom_nodes', entry['path'])
        saved = contained(backup / 'files', entry['path'])
        if dest.exists():
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(dest, saved)
        records.append({**entry, 'before': sha(dest)})
    journal = backup / 'rollback.json'
    journal.write_text(json.dumps({'comfy': str(comfy), 'files': records}, indent=2), encoding='utf-8')
    try:
        for entry in changes:
            dest = contained(comfy / 'custom_nodes', entry['path'])
            if sha(dest) != entry['base_sha256']:
                raise RuntimeError(f'File changed during installation: {entry["path"]}')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(contained(ROOT / 'payload', entry['path']), dest)
    except Exception:
        print(f'Installation interrupted. Recovery journal: {journal}')
        raise
    print(f'Installed {len(changes)} files. Restart ComfyUI and refresh the browser.')
    print(f'Rollback: python manage.py --comfy "{comfy}" rollback --backup "{backup}"')


def rollback(comfy, backup):
    journal = json.loads((backup / 'rollback.json').read_text(encoding='utf-8'))
    if Path(journal['comfy']).resolve() != comfy:
        raise ValueError('Backup belongs to a different ComfyUI installation.')
    changes = []
    for entry in journal['files']:
        dest = contained(comfy / 'custom_nodes', entry['path'])
        saved = contained(backup / 'files', entry['path'])
        if sha(saved) != entry['before']:
            raise ValueError(f'Backup damaged: {entry["path"]}')
        actual = sha(dest)
        if actual == entry['before']:
            continue
        if actual != entry['sha256']:
            raise ValueError(f'File changed after install; refusing rollback: {entry["path"]}')
        changes.append((dest, saved, entry))
    for dest, saved, entry in changes:
        if entry['before'] is None:
            dest.unlink()
        else:
            shutil.copyfile(saved, dest)
    print(f'Restored {len(changes)} files.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy', required=True, type=Path, help='ComfyUI folder containing custom_nodes and user')
    parser.add_argument('action', choices=['check', 'install', 'rollback'])
    parser.add_argument('--backup', type=Path)
    args = parser.parse_args()
    comfy = args.comfy.resolve()
    if not (comfy / 'custom_nodes').is_dir() or not (comfy / 'user').is_dir():
        parser.error('Expected an existing ComfyUI installation with custom_nodes and user folders.')
    if args.action == 'rollback':
        if args.backup is None:
            parser.error('rollback requires --backup')
        rollback(comfy, args.backup.resolve())
        return
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    problems, changes = inspect(comfy, manifest)
    if problems:
        print('\n'.join(problems))
        raise SystemExit('No changes made. Install the matching dependency versions first.')
    print(f'Checks passed; {len(changes)} files need installation.')
    if args.action == 'install' and changes:
        install(comfy, manifest, changes)


if __name__ == '__main__':
    main()
