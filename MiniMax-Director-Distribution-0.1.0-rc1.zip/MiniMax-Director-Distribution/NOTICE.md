# Source attribution

This is an unofficial integration patch distribution, not an upstream release.

- DaSiWa files in `payload/ComfyUI-DaSiWa-Nodes` derive from [darksidewalker/ComfyUI-DaSiWa-Nodes](https://github.com/darksidewalker/ComfyUI-DaSiWa-Nodes), GPL-3.0. The full upstream license is in `licenses/ComfyUI-DaSiWa-Nodes/LICENSE`.
- Extender files in `payload/ComfyUI_MiniMax_H3_Extender` derive from or integrate [tritant/ComfyUI_MiniMax_H3_Extender](https://github.com/tritant/ComfyUI_MiniMax_H3_Extender), Apache-2.0. The full upstream license is in `licenses/ComfyUI_MiniMax_H3_Extender/LICENSE`.
- HyperFlow is an external dependency from [Saganaki22/ComfyUI-Hyperflow](https://github.com/Saganaki22/ComfyUI-Hyperflow); its code and weights are not included.

Changes in this distribution (2026-09-26): Director scene timeline and approval UI; per-scene seeds and prompt snapshots; HyperFlow SIGMAS input; sequential Motion Context generation; output naming and previews; portable Director project archive endpoints. Payload files are modified integration versions, not unmodified upstream copies. Existing upstream copyright notices are retained.

New integration code, installation tools and example workflow are provided under GPL-3.0; see LICENSE. Upstream Apache-2.0 notices and terms continue to apply to the Extender portions. Models, user media, private projects and cached generations are not distributed.
