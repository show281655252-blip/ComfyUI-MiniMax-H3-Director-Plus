import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import manage


class InstallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.comfy = self.root / 'comfy'
        self.target = self.comfy / 'custom_nodes/example/node.py'
        self.target.parent.mkdir(parents=True)
        (self.comfy / 'user').mkdir()
        self.target.write_bytes(b'original\r\n')
        source = self.root / 'package/payload/example/node.py'
        source.parent.mkdir(parents=True)
        source.write_bytes(b'patched\n')
        new = source.with_name('new.py')
        new.write_bytes(b'new\n')
        self.manifest = {'dependencies': {}, 'files': [
            {'path': 'example/node.py', 'base_sha256': manage.sha(self.target), 'sha256': manage.sha(source)},
            {'path': 'example/new.py', 'base_sha256': None, 'sha256': manage.sha(new)},
        ]}
        self.patcher = patch.object(manage, 'ROOT', self.root / 'package')
        self.patcher.start()
        self.addCleanup(self.patcher.stop)

    def apply(self):
        problems, changes = manage.inspect(self.comfy, self.manifest)
        self.assertEqual(problems, [])
        manage.install(self.comfy, self.manifest, changes)
        return next((self.comfy / 'user').iterdir())

    def test_install_idempotency_and_exact_restore(self):
        backup = self.apply()
        self.assertEqual(manage.inspect(self.comfy, self.manifest), ([], []))
        manage.rollback(self.comfy, backup)
        self.assertEqual(self.target.read_bytes(), b'original\r\n')
        self.assertFalse(self.target.with_name('new.py').exists())

    def test_updated_target_refused_before_write(self):
        self.target.write_bytes(b'new upstream version')
        problems, changes = manage.inspect(self.comfy, self.manifest)
        self.assertTrue(problems)
        self.assertEqual(self.target.read_bytes(), b'new upstream version')

    def test_corrupted_payload_refused(self):
        (manage.ROOT / 'payload/example/node.py').write_bytes(b'damaged')
        self.assertTrue(manage.inspect(self.comfy, self.manifest)[0])

    def test_updated_file_prevents_all_rollback(self):
        backup = self.apply()
        self.target.write_bytes(b'user changes')
        with self.assertRaises(ValueError):
            manage.rollback(self.comfy, backup)
        self.assertEqual(self.target.with_name('new.py').read_bytes(), b'new\n')

    def test_tampered_backup_refused(self):
        backup = self.apply()
        (backup / 'files/example/node.py').write_bytes(b'damaged')
        with self.assertRaises(ValueError):
            manage.rollback(self.comfy, backup)

    def test_paths_stay_inside_installation(self):
        with self.assertRaises(ValueError):
            manage.contained(self.comfy, '../outside.py')

    def test_line_endings_do_not_change_code_identity(self):
        self.target.write_bytes(b'original\n')
        self.assertFalse(manage.inspect(self.comfy, self.manifest)[0])


if __name__ == '__main__':
    unittest.main()
